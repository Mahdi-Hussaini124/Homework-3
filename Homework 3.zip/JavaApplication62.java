
package javaapplication62;
import java.util.Scanner;

public class JavaApplication62 {

  
    public static void main(String[] args) {
        Scanner input= new Scanner(System.in);
        int x;
        x=input.nextInt();
        boolean s=(x==366);
        if (s){System.out.println("this is c year");
        
      
    } else {System.out.println("no");}
    
}
