package javaapplication66;

import java.util.Scanner;

public class JavaApplication66 {

    public static void main(String[] args) {
        double X = 5;
        X += 5;
        System.out.println(X);
        X -= 7;
        System.out.println(X);
        X *= 45;
        System.out.println(X);
        X /= 78;
        System.out.println(X);
        X %= 12;
        System.out.println(X);

    }

}
