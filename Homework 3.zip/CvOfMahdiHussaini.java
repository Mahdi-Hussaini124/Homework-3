/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication11;

/**
 *
 * @author rr
 */
public class JavaApplication11.java {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {System.out.println("Name/last name:Mahdi Hussaini");System.out.println("Fathers Name:Reza Hussaini");
    System.out.println("class : first");   System.out.println("job : student");   
      System.out.println("Major: Comouter sience");System.out.println("Province:Maidan Wardak");System.out.println("Fathers Job: Farmer");System.out.println("Date of birth :2006");System.out.println("ID Number :02001628");
      System.out.println("phone Number:0774997124");System.out.println("Fovorite Color :Blak");System.out.println("Mother tongue:Dari");System.out.println("Village:Iska");System.out.println("Ambition:To become a sientist");
}
