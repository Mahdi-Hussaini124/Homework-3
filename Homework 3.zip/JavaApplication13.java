/*
 
package javaapplication13;

/**
 * @author rr
 */
public class JavaApplication13 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {System.out.println("Name:Mahdi \n father name:Reza"
            + " "
            + "");
        // TODO code application logic here
    }
    
}
