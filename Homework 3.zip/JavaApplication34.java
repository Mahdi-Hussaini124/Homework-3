package javaapplication34;

import java.util.Scanner;

public class JavaApplication34 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double Minute, seccond;
        System.out.println("pleas enter the value of Minute");
        Minute = input.nextDouble();
        System.out.println("the result for seccond ");
        seccond = Minute * 60;

        System.out.println(seccond);

    }

}
